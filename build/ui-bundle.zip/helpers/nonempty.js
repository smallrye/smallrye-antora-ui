'use strict'

module.exports = (val) => val && val.length && val.length > 1
